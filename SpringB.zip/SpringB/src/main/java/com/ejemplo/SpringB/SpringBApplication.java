package com.ejemplo.SpringB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBApplication.class, args);
	}

}
