package com.ejemplo.SpringB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBApplicationTests {

	@Test
	void contextLoads() {
	}

}
